<template>
  <div id="app">
    <h1>GitHub Profile Viewer</h1>
    <UserProfileCard :username="'octocat'" />
  </div>
</template>

<script>
import UserProfileCard from './components/UserProfileCard.vue';

export default {
  name: 'App',
  components: {
    UserProfileCard,
  },
};
</script>

<style>
#app {
  text-align: center;
  padding: 20px;
}
</style>
