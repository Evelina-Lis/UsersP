<template>
  <div class="profile-card">
    <div class="profile-image">
      <img :src="user.avatar_url" :alt="`Avatar of ${user.name || 'User'}`" />
    </div>
    <div class="profile-content">
      <a :href="user.html_url" target="_blank" class="profile-name">{{ user.name || 'Unnamed User' }}</a>
      <div class="profile-meta">
        <span>Joined on {{ joinDate }}</span>
      </div>
      <p class="profile-bio">{{ user.bio || 'No biography available.' }}</p>
    </div>
    <div class="profile-footer">
      <a>
        <i class="icon users"></i>
        {{ user.followers || 0 }} Followers
      </a>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UserProfileCard',
  props: {
    username: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      user: {},
    };
  },
  computed: {
    joinDate() {
      if (!this.user.created_at) return 'Unknown';
      return new Date(this.user.created_at).toLocaleDateString();
    },
  },
  methods: {
    async loadUserData() {
      try {
        const res = await fetch(`https://api.github.com/users/${this.username}`);
        if (!res.ok) {
          console.error('Failed to fetch user data');
          return;
        }
        this.user = await res.json();
      } catch (err) {
        console.error('An error occurred:', err);
      }
    },
  },
  watch: {
    username: 'loadUserData',
  },
  mounted() {
    this.loadUserData();
  },
};
</script>

<style scoped>
.profile-card {
  max-width: 320px;
  border: 1px solid #ddd;
  border-radius: 5px;
  overflow: hidden;
  margin: 20px auto;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.profile-image img {
  width: 100%;
  height: auto;
  display: block;
}

.profile-content {
  padding: 15px;
  text-align: center;
}

.profile-name {
  font-size: 1.2em;
  color: #0073e6;
  text-decoration: none;
}

.profile-name:hover {
  text-decoration: underline;
}

.profile-meta {
  color: #555;
  font-size: 0.9em;
  margin: 5px 0;
}

.profile-bio {
  font-size: 1em;
  color: #333;
  margin-top: 10px;
}

.profile-footer {
  padding: 10px;
  background: #f9f9f9;
  text-align: center;
}

.profile-footer a {
  color: #0073e6;
  font-weight: bold;
  text-decoration: none;
}

.icon.users {
  margin-right: 5px;
}
</style>
