import { createApp } from 'vue';
import App from './App.vue';
import 'semantic-ui-css/semantic.min.css';

createApp(App).mount('#app');
